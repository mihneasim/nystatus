from setuptools import setup
import sys, os

version = '0.1'

setup(name='django-zopeproductversions',
      version=version,
      description="Django client for listing product version in specified zope instances",
      long_description="""\
""",
      classifiers=[
            'Development Status :: 3 - Alpha',
            'Environment :: Web Environment',
            'Framework :: Django',
            'Intended Audience :: Developers',
            'License :: OSI Approved :: GNU General Public License (GPL)',
            'Operating System :: OS Independent',
            'Programming Language :: Python',
            'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
            'Topic :: Software Development',
            'Topic :: Software Development :: Libraries :: Application Frameworks',
      ],
      keywords='zope version django client json product',
      author='Mihnea Simian',
      author_email='contact@mesimian.com',
      license='GPLv3',
      packages=['django_zopeproductversions'],
      include_package_data=True,
      zip_safe=False,
      requires=[
          'django (>=1.2)'
      ],
      )
